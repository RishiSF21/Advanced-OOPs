﻿using System;
namespace CafeteriaManagement;

class Program{
    public static void Main(string[] args)
    {
        Operations.DefaultData();
        //Calling the mainmenu
        Operations.MainMenu();
    }
}