﻿using System;
namespace MedicalStore;

class Program
{
    public static void Main(string[] args)
    {
        Operations.DefaultData();

        Operations.MainMenu();
    }
}